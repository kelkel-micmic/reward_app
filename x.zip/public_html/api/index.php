<?php 

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

require_once('Controller/User.php');

include __DIR__ . '/../vendor/autoload.php';

DB::$user = 'reco_admin';
DB::$password = 'Pknr9^b!aw*1phs5';
DB::$dbName = 'reco_admin';
DB::$encoding = 'utf8';

// DB::$host2 = '194.110.173.106';
// DB::$user2 = 'workfoli';
// DB::$password2 = 'nif0ZrDruBz)L9u0';
// DB::$dbName2 = 'work_main_db';



use Controller\User\User;


use Phroute\Phroute\Dispatcher;
use Phroute\Phroute\RouteCollector;
 

$router = new RouteCollector();
$user = new User();


date_default_timezone_set('Asia/Manila');


$router->get('api/employee-lists', fn() => $user->employee_lists());
$router->get('api/performance-data', fn() => $user->getPerformanceData());
$router->get('api/training-and-devs', fn() => $user->getTrainingData());
$router->get('api/skill-and-competencies', fn() => $user->getSkillsAndCompetencies());
$router->get('api/time-and-attendances', fn() => $user->getTimeAndAttendanceData());
$router->get('api/termination-and-offbs', fn() => $user->getTerminationData());
$router->get('api/succession-plannings', fn() => $user->getSuccessionPlanningData());
$router->get('api/recognition-and-rewards', fn() => $user->getRecognitionAndRewardsData());
$router->post('api/add-recognition-reward',fn() => $user->postRecognitionAndRewardsData());
$router->get('api/attendance-data', fn() => $user->attendance_data());
$router->post('api/view-attendance', fn() => $user->view_attendance());
$router->post('api/request-company-leave', fn() => $user->request_company_leave());
$router->get('api/get-leave-requests', fn() => $user->get_leave_requests());  
$router->post('api/update-leave-request-status', fn() => $user->updateLeaveRequestAndAddReward());
$router->post('api/add-reward', fn() => $user->insertTerminationReward());
$router->post('api/add-cash-reward-request', fn() => $user->request_cash_reward());
$router->get('/api/get-cashreward-requests', fn() => $user->get_cashreward_requests());
$router->post('api/update-cash-request-status', fn() => $user->updateCashRequestAndAddReward());



$router->post('api/user-login', fn() => $user->login_user());
$router->get('api/user-verify/{userid}', fn($userid) => $user->verify_user($userid));
$router->post('api/user-logout', fn() => $user->logout());


$dispatcher = new Dispatcher($router->getData());
$httpMethod = $_SERVER['REQUEST_METHOD'];
$uri = rawurldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
echo $dispatcher->dispatch($httpMethod, $uri), "\n";

    

?>