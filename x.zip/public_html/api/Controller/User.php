<?php
namespace Controller\User;

use Hashids\Hashids;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class User
{
	
	private $hash;
	private $db;
	private $auth;
    private $mail;
    private $spreadsheet;
    private $writer;
    private $mkdb;

	function __construct()
	{
        $this->mail = new PHPMailer(true);
		$this->hash = new Hashids('', 10);
		$this->db = new \MeekroDB();
        $this->spreadsheet = new Spreadsheet();
        $this->writer = new Xlsx($this->spreadsheet);
        $this->mkdb = new \PDO('mysql:dbname=reco_admin;host=localhost;charset=utf8mb4', 'reco_admin', 'Pknr9^b!aw*1phs5');
        $this->auth = new \Delight\Auth\Auth($this->mkdb);
        $this->mainDB = new \MeekroDB('194.110.173.106', 'workfoli', 'nif0ZrDruBz)L9u0', 'work_main_db');
        $this->pmDB = new \MeekroDB('194.110.173.106', 'workfoli', 'nif0ZrDruBz)L9u0', 'work_pm_sep');
        $this->scDB = new \MeekroDB('194.110.173.106', 'workfoli', 'nif0ZrDruBz)L9u0', 'work_sc_td');
        $this->toDB = new \MeekroDB('194.110.173.106', 'workfoli', 'nif0ZrDruBz)L9u0', 'work_to_esf');
        $this->rrDB = new \MeekroDB('194.110.173.106', 'workfoli', 'nif0ZrDruBz)L9u0', 'work_rr_sp');
        $this->lmDB = new \MeekroDB('194.110.173.106', 'workfoli', 'nif0ZrDruBz)L9u0', 'work_lm_ba');
	}

function insertTerminationReward() {


$employeeId = $_POST['employeeId'];
$rewardType = $_POST['rewardType'];
$rewardDescription = $_POST['rewardDescription'];
$rewardDate = $_POST['rewardDate']; 

$this->rrDB->insert('recognition_and_rewards', array(
    'employee_id' => $employeeId,
    'reward_type' => $rewardType,
    'reward_description' => $rewardDescription,
    'reward_date' => $rewardDate 
));
  
// $this->db->update('termination_and_offbs', array(
//     'rewarded' => 1
// ), 'employee_id=%i', 1);
  
  
  
echo json_encode(['status' => 'success']);

  
  
  
}



function updateLeaveRequestAndAddReward() {

    $requestId = $_POST['requestId'];
    $employeeId = $_POST['employeeId'];
    $statusUpdate = $_POST['statusUpdate'];
    $rewardType = $_POST['rewardType'];
    $rewardDescription = $_POST['rewardDescription'];

     $this->db->update('employee_leave_requests', array(
        'approval_status' => $statusUpdate
    ), "id=%i", $requestId);

    if ($statusUpdate === 'Approved') {
         $this->db->insert('recognition_and_rewards', array(
            'employee_id' => $employeeId,
            'reward_type' => $rewardType,
            'reward_description' => $rewardDescription,
            'reward_date' => $this->db->sqleval("CURDATE()") 
        ));
    }

    echo json_encode(['status' => 'success']);
}


function updateCashRequestAndAddReward() {

    $requestId = $_POST['requestId'];
    $employeeId = $_POST['employeeId'];
    $statusUpdate = $_POST['statusUpdate'];
   
     $this->db->update('cash_reward', array(
        'status' => $statusUpdate
    ), "id=%i", $requestId);

    // if ($statusUpdate === 'Approved') {
    //      $this->db->insert('recognition_and_rewards', array(
    //         'employee_id' => $employeeId,
    //         'reward_type' => $rewardType,
    //         'reward_description' => $rewardDescription,
    //         'reward_date' => $this->db->sqleval("CURDATE()") 
    //     ));
    // }

    echo json_encode(['status' => 'success']);
}








public function get_leave_requests(){

$requests = $this->lmDB->query("
SELECT elr.*, CONCAT(e.first_name, ' ', e.last_name) AS employeeName 
FROM tblleaves elr JOIN work_main_db.employees e ON elr.empid = e.id");

echo json_encode($requests);

}

public function get_cashreward_requests(){

    $requests = $this->db->query("SELECT elr.*, CONCAT(e.first_name, ' ', e.last_name) AS employeeName FROM cash_reward elr JOIN employees e ON elr.employee_id = e.id");
    
     echo json_encode($requests);
    
}




// var formData = {
//     employeeId: $('#employeeIdForReward').val(),
//     rewardType: $('#rewardType').val(),
//     cashrewardDescription: $('#cashrewardDescription').val(),
//     RewardedDate: $('#RewardedDate').val() 
// };





public function request_cash_reward(){
    $this->db->insert('cash_reward', [
          'employee_id' => $_POST['employeeId'],
          'cash_reward' => $_POST['cashrewardType'],
          'rewarded_date' => $_POST['RewardedDate'],
          'reward_description' => $_POST['cashrewardDescription'],
          'status' => 'Pending' 
      ]);
  
      echo json_encode(['status' => 'success']);
  }



public function request_company_leave(){
    $employeeId = isset($_POST['employeeId']) ? intval($_POST['employeeId']) : 0;
    $leaveType = isset($_POST['leaveType']) ? $_POST['leaveType'] : '';
    $leaveStartDate = isset($_POST['startDate']) ? $_POST['startDate'] : '';
    $leaveEndDate = isset($_POST['endDate']) ? $_POST['endDate'] : '';
    $description = isset($_POST['description']) ? $_POST['description'] : '';


    $this->lmDB->insert('tblleaves', [
        'empid' => $employeeId,
        'LeaveType' => $leaveType,
        'FromDate' => $leaveStartDate,
        'ToDate' => $leaveEndDate,
        'Description' => $description,
        'status' => 0       
    ]);

    echo json_encode(['status' => 'success']);
}
    public function view_attendance()
    {

        extract($_POST);

        $names = $this->db->query("SELECT DISTINCT(name) FROM api_attendance WHERE name='$name'");

         $monthly_average = [];


         for ($i=1; $i < 13; $i++) { 
             
            $number_sets = [];

            foreach ($names as $row) {
             
                $emp = $row['name'];

                $count = $this->db->query("SELECT count(*) as count FROM api_attendance WHERE name='$emp' AND month(date_inserted) in ($i)");

                array_push($number_sets, $count[0]['count']);


            }


            $sum = array_sum($number_sets);
            $count = count($number_sets);
            $average = $sum / $count;

            array_push($monthly_average, $average);


          }  


          $attendance = $this->db->query("SELECT * FROM api_attendance WHERE name='$name'");

          echo json_encode(["average" => $monthly_average, "attendance" => $attendance ]);

    }

    public function attendance_data(){
        $performanceData = $this->pmDB->query(  "SELECT pd.*, e.first_name, e.middle_name, e.last_name 
        FROM performance_data pd
        JOIN work_main_db.employees e ON pd.employee_id = e.id");


        echo json_encode(["employee" => $performanceData]);
        // $names = $this->db->query("SELECT DISTINCT(name) FROM api_attendance");

        // $data = [];

        // foreach ($names as $row) {
        //     $name = $row['name'];

        //     $info = $this->db->query("SELECT * FROM api_attendance WHERE name='$name' LIMIT 1");

        //     array_push($data, $info[0]);

        // }

        //echo json_encode(["employee" => $data]);
    }

    public function postRecognitionAndRewardsData(){
            $employeeId = $_POST['employeeId'];
            $rewardType = $_POST['rewardType'];
            $rewardDate = $_POST['rewardDate'];
            $rewardDescription = $_POST['rewardDescription'];

           $this->rrDB->insert('recognition_and_rewards', array(
                'employee_id' => $employeeId,
                'reward_type' => $rewardType,
                'reward_date' => $rewardDate,
                'reward_description' => $rewardDescription
            ));

            echo json_encode(array('success' => true));
    }




    public function getRecognitionAndRewardsData() {
    $rewardsData = $this->rrDB->query("SELECT 
                                    recognition_and_rewards.*, 
                                    employees.first_name, 
                                    employees.last_name 
                                 FROM 
                                    recognition_and_rewards 
                                 JOIN 
                                 work_main_db.employees 
                                 ON 
                                    recognition_and_rewards.employee_id = employees.id
                                 ORDER BY 
                                    recognition_and_rewards.reward_date DESC");
    echo json_encode(["rewardsData" => $rewardsData]);
}

     public function getSuccessionPlanningData() {
    //         $planningData = $this->rrDB->query("
    //         SELECT sp.*, CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
    //         sk.skill_name,
    //         tr.competency_level,
    //         pd.performance_scoring, 
    //         rr.reward_type FROM succession_plannings sp 
    //         JOIN work_main_db.employees e ON sp.employee_id = e.id 
    //         LEFT JOIN work_sc_td.trained_employee tr ON tr.employee_id = e.id 
    //         LEFT JOIN work_sc_td.skills sk ON sk.skill_id = tr.employee_skill 
    //         LEFT JOIN work_pm_sep.employee_rankings pd ON pd.employee_id = e.id 
    //         LEFT JOIN recognition_and_rewards rr ON sp.employee_rewardandrecog = rr.id;  
    // ");
    $planningData = $this->mainDB->query("
    SELECT 
    e.*, 
    CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
    sk.skill_name,
    tr.competency_level,
    pd.performance_scoring,
    rr.reward_type
    FROM 
    employees e
    LEFT JOIN
    work_sc_td.trained_employee tr ON tr.employee_id = e.id
    LEFT JOIN 
    work_pm_sep.employee_rankings pd ON pd.employee_id = e.id
    LEFT JOIN
    work_sc_td.skills sk ON sk.skill_id = tr.employee_skill
    LEFT JOIN
    work_rr_sp.recognition_and_rewards rr ON rr.employee_id = e.id; 
    ");


            echo json_encode(["planningData" => $planningData]);
    }

    public function getTerminationData() {
            $terminationData = $this->toDB->query("SELECT t.*, CONCAT(e.first_name, ' ', e.last_name) AS employee_name 
                 FROM offboarding_requests t
                 JOIN work_main_db.employees e ON t.employee_id = e.id");
            echo json_encode(["terminationData" => $terminationData]);
        }

    public function getTimeAndAttendanceData() {
        $attendanceData = $this->db->query("SELECT ta.*, CONCAT(e.first_name, ' ', e.last_name) AS employee_name 
                 FROM time_and_attendances ta
                 JOIN employees e ON ta.employee_id = e.id");
        echo json_encode(["attendanceData" => $attendanceData]); 
    }


    public function getSkillsAndCompetencies() {
            $skillsData = $this->scDB->query("SELECT sc.*, s.skill_name, CONCAT(e.first_name, ' ', e.last_name) AS employee_name 
                 FROM trained_employee sc
                 JOIN work_main_db.employees e ON sc.employee_id = e.id
                 JOIN skills s ON sc.employee_skill = s.skill_id
                 ");
            echo json_encode(["skillsData" => $skillsData]);
    }

     public function getTrainingData() {
     
     $trainingData = $this->scDB->query("SELECT sc.*, s.skill_name, CONCAT(e.first_name, ' ', e.last_name) AS employee_name 
     FROM trained_employee sc
     JOIN work_main_db.employees e ON sc.employee_id = e.id
     JOIN skills s ON sc.employee_skill = s.skill_id 
     ");
    
            echo json_encode(["trainingData" => $trainingData]);     
    }

    public function getPerformanceData() {

        $performanceData = $this->pmDB->query(  "SELECT pd.*, e.first_name, e.middle_name, e.last_name 
            FROM performance_data pd
            JOIN work_main_db.employees e ON pd.employee_id = e.id");
        echo json_encode(["performanceData" => $performanceData]);
        
    }


    public function employee_lists()
    {

        $employee = $this->mainDB->query("SELECT *FROM work_main_db.employees");

        echo json_encode(["employees" => $employee]);
    }

    public function login_user()
    {   

        extract($_POST);

        try {

            $this->auth->login($email, $password);

            $id = $this->get_user_id();

            $info = $this->db->query("SELECT * FROM users WHERE id='$id'");    

            $_SESSION["system"] = $info;

            echo json_encode(["response"=>'Successfuly login', "status"=>1]);
        }
        catch (\Delight\Auth\InvalidEmailException $e) {
            echo json_encode(["response"=>'Wrong email address', "status"=>0]);
        }
        catch (\Delight\Auth\InvalidPasswordException $e) {
            echo json_encode(["response"=>'Wrong password', "status"=>0]);
        }
        catch (\Delight\Auth\EmailNotVerifiedException $e) {
            echo json_encode(["response"=>'Email not verified', "status"=>0]);
        }
        catch (\Delight\Auth\TooManyRequestsException $e) {
            echo json_encode(["response"=>'Too many requests', "status"=>0]);
        }

    }

    public function register_user()
    {

        extract($_POST);
        try {

            $userId = $this->auth->register($email, $password, $username, function ($selector, $token) {

            });

            $this->verification($email, $this->hash->encode($userId));

            echo json_encode(["response"=>'Verification email has been sent!', "status"=>1]);
        }
        catch (\Delight\Auth\InvalidEmailException $e) {
            echo json_encode(["response"=>'Invalid email address', "status"=>0]);
        }
        catch (\Delight\Auth\InvalidPasswordException $e) {
            echo json_encode(["response"=>'Invalid password', "status"=>0]);
        }
        catch (\Delight\Auth\UserAlreadyExistsException $e) {
            echo json_encode(["response"=>'User already exists', "status"=>0]);
        }
        catch (\Delight\Auth\TooManyRequestsException $e) {
            echo json_encode(["response"=>'Too many requests', "status"=>0]);
        }

    }

    public function verify_user($userid)
    {

        $this->db->query("UPDATE users SET verified=%i WHERE id=%i", 1, $this->hash->decode($userid)[0]);

        header("location: http://localhost/lms/index.php");

    }



    public function verification($email, $userid)
    {

        try {
            //Server settings
            // $this->mail->SMTPDebug = SMTP::DEBUG_SERVER;
            $this->mail->SMTPDebug = false; //Enable verbose debug output
            $this->mail->isSMTP(); //Send using SMTP
            $this->mail->Host = 'smtp.gmail.com'; //Set the SMTP server to send through
            $this->mail->SMTPAuth = true; //Enable SMTP authentication
            $this->mail->Username = 'conniebenetez@gmail.com'; //SMTP username
            $this->mail->Password = 'wdwfpioudaqphwiw'; //SMTP password
            $this->mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; //Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
            $this->mail->Port = 587; //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above            
            //Recipients
            $this->mail->setFrom('conniebenetez@gmail.com', 'verification');
            $this->mail->addAddress($email); //Add a recipient

            //Content
            $this->mail->isHTML(true); //Set email format to HTML
            $this->mail->Subject = 'Verification Email';
            // $this->mail->Body = "<span style="width:50%; height:50%;"> <img src="img/logo2.png" style="width:50%; height:50%;"> </span> <h1>Click the link to verify account: <a href='http://localhost/batangas/api/user-verify/".$userid."' >Verify account</a></h1>";
            $this->mail->Body = "<h2> Greetings User! <h2> <br> <h3>Click the link to verify account: <a href='http://localhost/lms/studentapi/user-verify/".$userid."' >Verify account</a></h3>";

            $this->mail->send();
            // echo 'Message has been sent';
         
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
      


    }

    public function logout()
    {
        $this->auth->logOut();   
        unset($_SESSION['system']);
        echo json_encode(["response" => "logout"]);
    }

    public function checking_auth()
    {

        $LoggedIn = false;

        if ($this->auth->isLoggedIn()) {
            $LoggedIn = true;
        }

        return $LoggedIn;
    }

    public function get_user_id()
    {
    $id = $this->auth->getUserId();
    return $id;
    }

}


?>