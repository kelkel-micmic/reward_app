<?php
session_start();

require 'vendor/autoload.php';

$mainDB = new \MeekroDB('194.110.173.106', 'workfoli', 'nif0ZrDruBz)L9u0', 'work_main_db');

if (isset($_GET['token'])) {

	extract($_GET);

	$checking = $mainDB->query("SELECT * FROM work_main_db.users as user WHERE user.token='$token'");

	if ($checking) {
		header('location: https://recognr-succps.workfoliohumanresource.com/admin/?recognitionrewards');
	}else{
		header('location: https://workfoliohumanresource.com');
	}

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<link rel="canonical" href="https://demo-basic.adminkit.io/pages-sign-in.html" />

	<title>Recognition and rewards succession planning | Login</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>

<body>
	<main class="d-flex w-100" style="background: rgb(225,124,242);background: linear-gradient(110deg, rgba(225,124,242,1) 0%, rgba(0,201,221,1) 50%, rgba(181,219,1,1) 100%);">
		<div class="container d-flex flex-column">
			<div class="row vh-100">
				<div class="col-sm-10 col-md-8 col-lg-6 col-xl-5 mx-auto d-table h-100">
					<div class="d-table-cell align-middle">

						<div class="text-center mt-4">
							
							<img src="img/logo.png" style="height: 250px;">
							<h1 class="h1" style="font-size: 40px; color: #DC2B7C;"><b><i style="color: #3b7ddd;">Recognition and </i>rewards succession planning</b></h1>
							<p class="lead">
								Sign in to your account to continue
							</p>
						</div>

						<div class="card">
							<div class="card-body">
								<div class="m-sm-3">
								
										<div class="mb-3">
											<label class="form-label">Email</label>
											<input class="form-control form-control-lg" type="email" id="email" placeholder="Enter your email" />
										</div>
										<div class="mb-3">
											<label class="form-label">Password</label>
											<input class="form-control form-control-lg" type="password" id="password" placeholder="Enter your password" />
										</div>

										<div class="d-grid gap-2 mt-3">
											<button class="btn btn-lg btn-primary" id="form-submit" type="button">Sign in</button>
										</div>
								
								</div>
							</div>
						</div>
						<div class="text-center mb-3">
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</main>

	<script src="js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<script src="js/app.js"></script>
	<script type="text/javascript">
		

        $(document).on("click", "#form-submit", ()=>{

	        $.ajax({
	            url:"api/user-login",
	            type: "POST",
	            dataType: "json",
	            data: {
	                email: $("#email").val(),
	                password: $("#password").val()
	            },
	            beforeSend: (e) => {
	            Swal.fire({
	              html: 'Loading...',
	              didOpen: () => {
	                Swal.showLoading()
	              }
	            })
	            },
	            success: (data) => { 

	            Swal.close(); 

	            if (data.status == 1) {
	                Swal.fire({
	                  icon: 'success',
	                  title: 'Login succesfully.',
	                  confirmButtonColor: '#3085d6',
	                  cancelButtonColor: '#d33',
	                  confirmButtonText: 'Ok'
	                }).then((result) => {
	                  if (result.isConfirmed) {
	                    window.location.href = "https://recognr-succps.workfoliohumanresource.com/admin/?employees";
	                  }
	                })
	            }else{
	                Swal.fire({
	                  icon: 'error',
	                  title: data.response,
	                  confirmButtonColor: '#3085d6',
	                  cancelButtonColor: '#d33',
	                  confirmButtonText: 'Ok'
	                }).then((result) => {
	                  if (result.isConfirmed) {
	                   
	                  }
	                })
	            }

	          }

	         }); 

        });

	</script>
</body>

</html>