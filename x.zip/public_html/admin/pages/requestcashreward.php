<div class="container mt-5">
    <h2><strong>Cash Requests Overview</strong></h2>
    <div class="card">
        <div class="card-body">
            <table id="cashRequestsTable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Employee Name</th>
                        <th>Cash Reward Request Type</th>
                        <th>Rewarded Date</th>
                        <th>Description</th>
                        <th>Approval Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="modal fade" id="updateStatusModal" tabindex="-1" aria-labelledby="updateStatusModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="updateStatusModalLabel">Update Cash Request Status</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="updateStatusForm">
          <input type="hidden" id="requestId" name="requestId">
          <input type="hidden" id="employeeIdForStatusUpdate" name="employeeId">
          <div class="mb-3">
            <label for="statusUpdate" class="form-label">Status</label>
            <select class="form-select" id="statusUpdate" name="statusUpdate">
              <option value="Pending">Pending</option>
              <option value="Approved">Approved</option>
              <option value="Denied">Denied</option>
            </select>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onclick="submitUpdate()">Submit</button>
      </div>
    </div>
  </div>
</div>
