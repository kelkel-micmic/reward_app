<div class="container mt-5">
        <h1 class="mb-4"><strong>Performance Data Overview</strong></h1>
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered" id="performanceDataTable">
                    <thead>
                        <tr>
                            <th>Employee Name</th>
                            <th>Average Feedback Rating</th>
                            <th>Average Present</th>
                            <th>Average Absent</th>
                            <th>Skill Name</th>
                            <th>Skill Competency Level</th>
                            <th>Date Inserted</th>
                        </tr>
                    </thead>
                    <tbody id="performance-data-body">
                    </tbody>
                </table>
            </div>
        </div>
    </div>