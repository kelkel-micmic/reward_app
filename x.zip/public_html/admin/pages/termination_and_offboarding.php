<div class="container mt-5">
    <h1 class="mb-4"><strong>Termination and Offboarding Records</strong></h1>
    <div class="card">
        <div class="card-body">
            <table class="table table-bordered" id="terminationTable">
                <thead>
                    <tr>
                        <th>Employee Name</th>
                        <!-- <th>Onboard Date</th>
                        <th>Termination Date</th> -->
                        <th>Reason</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="rewardModal" tabindex="-1" aria-labelledby="rewardModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="rewardModalLabel">Add Reward</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="rewardForm">
          <div class="mb-3">
            <label for="rewardType" class="form-label">Reward Type</label>
            <input type="text" class="form-control" id="rewardType" name="rewardType">
          </div>
          <div class="mb-3">
            <label for="rewardDescription" class="form-label">Reward Description</label>
            <textarea class="form-control" id="rewardDescription" name="rewardDescription" rows="3"></textarea>
          </div>
          <div class="mb-3">
            <label for="rewardDate" class="form-label">Reward Date</label>
            <input type="date" class="form-control" id="rewardDate" name="rewardDate">
          </div>
          <input type="hidden" id="employeeIdForReward" name="employeeId">
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="submitReward">Submit</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="cashrewardModal" tabindex="-1" aria-labelledby="cashrewardModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="rewardModalLabel">Request Cash Reward</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="addCashRewardForm">
          <input type="hidden" id="employeeIdForReward" name="employeeId">
          <div class="mb-3">
            <label for="cashrewardType" class="form-label">Cash Reward Type</label>
            <input type="text" class="form-control" id="cashrewardType" name="cashrewardType"  required >
          </div>
          <div class="mb-3">
            <label for="leaveStartDate" class="form-label">Rewarded Date</label>
            <input type="date" class="form-control" id="RewardedDate" name="RewardedDate" required>
          </div>
          <div class="mb-3">
            <label for="rewardDescription" class="form-label">Rewarded Description</label>
            <textarea class="form-control" id="cashrewardDescription" name="cashrewardDescription" rows="3" required></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary request_cash_reward" id="">Submit Request</button>
      </div>
    </div>
  </div>
</div>