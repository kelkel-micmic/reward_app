<div class="container mt-5">
    <h1 class="mb-4"><strong>Training and Development Records</strong></h1>
    <div class="card">
        <div class="card-body">
            <table class="table table-bordered" id="trainingTable">
                <thead>
                    <tr>
                        <th>Employee Name</th>
                        <th>Skill Type</th>
                        <!-- <th>Training Start Date</th>
                        <th>Training End Date</th> -->
                        <th>Competency Level</th>
                        <th>Status Completion</th>
                        <th>Action</th> 
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="modal fade" id="addTrainingRewardModal" tabindex="-1" aria-labelledby="addTrainingRewardModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addTrainingRewardModalLabel">Add Reward to Training Session</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="addTrainingRewardForm">
                    <div class="mb-3">
                        <label for="trainingRewardType" class="form-label">Reward Type</label>
                        <input type="text" class="form-control" id="trainingRewardType" name="rewardType" required>
                    </div>
                    <div class="mb-3">
                        <label for="trainingRewardDate" class="form-label">Reward Date</label>
                        <input type="date" class="form-control" id="trainingRewardDate" name="rewardDate" required>
                    </div>
                    <div class="mb-3">
                        <label for="trainingRewardDescription" class="form-label">Description</label>
                        <textarea class="form-control" id="trainingRewardDescription" name="description" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="employeeForReward" class="form-label">Employee</label>
                        <select class="form-control" id="employeeForReward" name="employeeId" required>
                            <!-- Dynamically populate this select with options -->
                        </select>
                    </div>
                    <!-- Optionally, add other fields here as necessary -->
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>
