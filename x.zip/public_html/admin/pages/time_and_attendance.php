
<h1 class="h3 mb-3"><strong>Time and Attendance</strong></h1>

<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<table class="table table-bordered" id="att-tbl">
					<thead>
						<tr>
							<th>Fullname</th>
							<th>Average Absent</th>
							<th>Average Present</th>
							<th>Tools</th>
						</tr>
					</thead>
					<tbody id="att-body">
						
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="view-modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modal-title">Employee Attendance</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

      	<div class="row">
      		<div class="col-md-8">
				<div class="card flex-fill w-100">
					<div class="card-header">

						<h5 class="card-title mb-0">Recent Attendance Average Movement per month</h5>
					</div>
					<div class="card-body py-3">
						<div class="chart chart-sm">
							<canvas id="chartjs-dashboard-line"></canvas>
						</div>
					</div>
				</div>
      		</div>
      		<div class="col-md-4">
				<div class="card flex-fill w-100">
					<div class="card-header">

						<h5 class="card-title mb-0">Recent Attendance</h5>
					</div>
					<div class="card-body py-3" style="overflow-y: scroll; height: 300px;">
						<table class="table mb-0" >
							<tbody id="att">


							</tbody>
						</table>
					</div>
				</div>
      		</div>
      	</div>



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>




<!-- Leave Request Modal -->
<div class="modal fade" id="leave-modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="leaveModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="leaveModalLabel">Leave Request</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

      	<div class="row">
      		<div class="col-md-6">
				<input type="hidden" id="employee-id" value="">
				<div class="mb-3">
					<label for="leave-type" class="form-label">Leave Type</label>
					<input type="text" class="form-control" id="leave-type" placeholder="Leave Type">
				</div>
				<div class="mb-3">
					<label for="start-date" class="form-label">Start Date</label>
					<input type="date" class="form-control" id="start-date">
				</div>
				<div class="mb-3">
					<label for="end-date" class="form-label">End Date</label>
					<input type="date" class="form-control" id="end-date">
				</div>
      		</div>
      		<div class="col-md-6">
				<div class="mb-3">
					<label for="description" class="form-label">Description</label>
					<textarea class="form-control" id="description" rows="5"></textarea>
				</div>
				<div class="mb-3">
					<label for="request-date" class="form-label">Request Date</label>
					<input type="date" class="form-control" id="request-date">
				</div>
      		</div>
      	</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" id="submit-request-btn" class="btn btn-primary">Submit Request</button>
      </div>
    </div>
  </div>
</div>
