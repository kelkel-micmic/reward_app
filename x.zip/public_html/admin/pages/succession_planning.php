<div class="container mt-5">
    <h1 class="mb-4"><strong>Succession Planning Records</strong></h1>

    <!-- Dropdown for filtering by Skills -->
    <label for="skillsFilter">Filter by Skills:</label>
    <div class="card">
        <div class="card-body">
            <table class="table table-bordered" id="planningTable">
                <thead>
                    <tr>
                        <th>Employee Name</th>
                        <th>Skills</th>
                        <th>Performance Rating</th>
                        <th>Reward and Recognition</th>
                        <th>Competency Level</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Dynamic succession planning data rows will be inserted here -->
                </tbody>
            </table>
        </div>
    </div>
</div>
