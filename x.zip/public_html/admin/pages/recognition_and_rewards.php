<div class="container mt-5">
        <h1 class="mb-4"><strong>Recognition and Rewards</strong></h1>
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered" id="rewardsTable">
                    <thead>
                        <tr>
                            <th>Employee Name</th>
                            <th>Reward Type</th>
                            <th>Reward Date</th>
                            <th>Reward Description</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


