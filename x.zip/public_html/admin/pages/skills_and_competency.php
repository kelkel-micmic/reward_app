 
 <div class="container mt-5">
        <h1 class="mb-4"><strong>Skills and Competencies</strong></h1>
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered" id="skillsTable">
                    <thead>
                        <tr>
                            <th>Employee Name</th>
                            <th>Skill</th>
                            <th>Competency Level</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Dynamic skill and competency data rows will be inserted here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>