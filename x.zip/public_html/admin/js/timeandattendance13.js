$.ajax({
  url:"../api/attendance-data",
  type: "GET",
  dataType: "json",
  beforeSend: (e) => {
  Swal.fire({
    html: 'Loading...',
    didOpen: () => {
      Swal.showLoading()
    }
  })
  },
  success: (data) => { 

      Swal.close();

      $("#att-body").empty();

      $.each(data.employee, (i, e)=>{
          console.log(e);

          $("#att-body").append(`
              <tr>
                  <td>${e.first_name + e.middle_name}</td>
                  <td>${e.ave_absent}%</td>
                  <td>${e.ave_present}%</td>
                  <td>
                      <button class="btn btn-success btn-sm leave-modal" data-empid="${e.employee_id}">Request Leave</button>
                  </td>
              </tr>
          `);

      });

      $("#remote-tbl").DataTable();

  },
  error: (xhr, ajaxOptions, thrownError) => {

      Swal.close(); 
    
      Swal.fire({
        icon: 'error',
        title: xhr.status,
        text: thrownError,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ok'
      }).then((result) => {
        if (result.isConfirmed) {
         
        }
      });

  }
 });



$(document).on("click", ".leave-modal", (e)=>{
  const employeeId = $(e.target).data("empid");
  $("#employee-id").val(employeeId);
  $("#leave-modal").modal("show");

});



$("#submit-request-btn").on("click", () => {
  const leaveType = $("#leave-type").val();
  const startDate = $("#start-date").val();
  const endDate = $("#end-date").val();
  const description = $("#description").val();
  const requestDate = $("#request-date").val();
  const employeeId = $("#employee-id").val();

  const requestData = {
      leaveType: leaveType,
      startDate: startDate,
      endDate: endDate,
      description: description,
      requestDate: requestDate,
      employeeId: employeeId
  };

  $.ajax({
      url: "../api/request-company-leave", 
      type: "POST",
      dataType: "json",
      data: requestData,
      success: (response) => {
          console.log("Leave request submitted successfully:", response);
          $("#leave-modal").modal("hide");
      },
      error: (xhr, ajaxOptions, thrownError) => {
          console.error("Error submitting leave request:", xhr.status, thrownError);
      }
  });
});
