
$.ajax({
    url: "../api/get-leave-requests", 
    type: "GET",
    dataType: "json",
    beforeSend: function() {
        Swal.fire({
            title: 'Loading...',
            didOpen: () => {
                Swal.showLoading()
            },
            allowOutsideClick: false,
            allowEscapeKey: false
        });
    },
    success: function(response) {

            console.log(response);
        Swal.close();
        const tbody = $("#leaveRequestsTable tbody");
        tbody.empty();

        $.each(response, function(i, request) {
            let actionButton = '';
            let statusText = '';
            
            if (request.Status === '1') {
                statusText = 'Approved';
                actionButton = `<button class="btn btn-primary btn-sm updateStatusButton" data-bs-toggle="modal" data-bs-target="#updateStatusModal" data-request-id="${request.id}" data-employee-id="${request.empid}" data-leave-type="${request.LeaveType}" data-description="${request.Description}" data-employee-name="${request.employeeName}">Reward</button>`;
            } else {
                statusText = 'Not Approved';
           
            }

            // if (request.approval_status !== 'Approved') {
            //  actionButton = `<button class="btn btn-primary btn-sm updateStatusButton" data-bs-toggle="modal" data-bs-target="#updateStatusModal" data-request-id="${request.id}" data-employee-id="${request.empid}" data-leave-type="${request.LeaveType}" data-description="${request.Description}" data-employee-name="${request.employeeName}">Update Status</button>`;
            // }

            const tr = $("<tr>").append(
                $("<td>").text(request.employeeName),
                $("<td>").text(request.LeaveType),
                $("<td>").text(new Date(request.FromDate).toLocaleDateString()), 
                $("<td>").text(new Date(request.ToDate).toLocaleDateString()), 
                $("<td>").text(request.Description),
                $("<td>").text(new Date(request.PostingDate).toLocaleDateString()),
                $("<td>").text(statusText),
                // $("<td>").html(actionButton)
            );
            tbody.append(tr);
        });



        if (!$.fn.DataTable.isDataTable("#leaveRequestsTable")) {
            $("#leaveRequestsTable").DataTable(); 
        } else {
            $("#leaveRequestsTable").DataTable().draw(); 
        }
    },
    error: function(xhr, status, error) {
        Swal.close();
        Swal.fire("Error", "Could not fetch leave requests: " + error, "error");
    }
});

$('#updateStatusModal').on('show.bs.modal', function (event) {
var button = $(event.relatedTarget); 
var requestId = button.data('request-id');
var employeeId = button.data('employee-id'); 
var leaveType = button.data('leave-type'); 
var description = button.data('description'); 
console.log(employeeId);

var modal = $(this);
modal.find('.modal-body #employeeIdForStatusUpdate').val(employeeId);
modal.find('.modal-body #requestId').val(requestId);
modal.find('.modal-body #rewardType').val(leaveType).prop('readonly', true); 
modal.find('.modal-body #rewardDescription').val(description).prop('readonly', true);; 
});



function submitUpdate() {
var formData = $("#updateStatusForm").serialize();
$.ajax({
    url: "../api/update-leave-request-status", 
    type: "POST",
    data: formData,
    success: function(response) {
        $('#updateStatusModal').modal('hide');
        Swal.fire('Success', 'Update successful!', 'success');
        location.reload();
    },
    error: function(xhr, textStatus, errorThrown) {
        Swal.fire('Error', 'Update failed: ' + errorThrown, 'error');
    }
});
}