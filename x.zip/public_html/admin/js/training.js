	$.ajax({
	  url:"../api/training-lists",
	  type: "GET",
	  dataType: "json",
	  beforeSend: (e) => {
	  Swal.fire({
	    html: 'Loading...',
	    didOpen: () => {
	      Swal.showLoading()
	    }
	  })
	  },
	  success: (data) => { 

	  	Swal.close();

	  	$("#training-body").empty();

	  	$.each(data.training, (i, e)=>{

	  		$("#training-body").append(`
	  			<tr>
	  				<td>${e.trainee}</td>
	  				<td>${e.training}</td>
	  				<td>${e.start_date}</td>
	  				<td>${e.end_date}</td>
	  				<td>${e.status == 0 ? '<span class="badge bg-success">Ongoing</span>' : '<span class="badge bg-danger">Ended</span>'}</td>
	  				<td>
	  				<button class="btn btn-success btn-sm viewtraining" 
	  				data-trainee="${e.trainee}"
	  				data-training="${e.training}"
	  				data-start="${e.start_date}"
	  				data-end="${e.end_date}"
	  				data-description="${e.description}"
	  				data-status="${e.status}"
	  				data-duration="${e.duration}"
	  				data-result="${e.result}"
	  				data-incharge="${e.incharge}"
	  				> View </button>
	  				</td>
	  			</tr>
	  		`);

	  	});

	  	$("#training-tbl").DataTable();

	  },
	  error: (xhr, ajaxOptions, thrownError) => {

	      Swal.close(); 
	    
	      Swal.fire({
	        icon: 'error',
	        title: xhr.status,
	        text: thrownError,
	        confirmButtonColor: '#3085d6',
	        cancelButtonColor: '#d33',
	        confirmButtonText: 'Ok'
	      }).then((result) => {
	        if (result.isConfirmed) {
	         
	        }
	      });

	  }
	 });


	$(document).on("click", ".viewtraining", (e)=>{

		$("#view-modal").modal("show");

		$("#info-table").empty().append(`
      		<tbody>
      		  <tr>
      			<td><b>Trainee</b></td>
      			<td>${e.target.dataset.trainee}</td>
      		  </tr>	
      		  <tr>
      			<td><b>Training</b></td>
      			<td>${e.target.dataset.training}</td>
      		  </tr>	
      		  <tr>
      			<td><b>Start Date</b></td>
      			<td>${e.target.dataset.start}</td>
      		  </tr>	
      		  <tr>
      			<td><b>End Date</b></td>
      			<td>${e.target.dataset.end}</td>
      		  </tr>	
      		  <tr>
      			<td><b>Description</b></td>
      			<td>${e.target.dataset.description}</td>
      		  </tr>	
      		  <tr>
      			<td><b>Status</b></td>
      			<td>${e.target.dataset.status == 0 ? '<span class="badge bg-success">Ongoing</span>' : '<span class="badge bg-danger">Ended</span>'}</td>
      		  </tr>	
      		  <tr>
      			<td><b>Duration</b></td>
      			<td>${e.target.dataset.duration}</td>
      		  </tr>	
      		  <tr>
      			<td><b>Result</b></td>
      			<td>${e.target.dataset.result}</td>
      		  </tr>	
      		  <tr>
      			<td><b>Incharge</b></td>
      			<td>${e.target.dataset.incharge}</td>
      		  </tr>	
      		</tbody>
		`)


	});