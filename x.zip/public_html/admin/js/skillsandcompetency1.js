    $.ajax({
        url: "../api/skill-and-competencies", // Adjust to your API endpoint
        type: "GET",
        dataType: "json",
        beforeSend: function() {
            Swal.fire({
                title: 'Loading...',
                didOpen: () => {
                    Swal.showLoading()
                },
                allowOutsideClick: false,
                allowEscapeKey: false
            });
        },
        success: function(response) {
        	console.log(response);
            Swal.close();

            const tbody = $("#skillsTable tbody");
            tbody.empty();

            $.each(response.skillsData, function(i, skill) {
                const tr = $("<tr>").append(
                    $("<td>").text(skill.employee_name),
                    $("<td>").text(skill.skill_name),
                    $("<td>").text(skill.competency_level)
                );
                tbody.append(tr);
            });

            // Initialize or re-draw DataTable
            if (!$.fn.DataTable.isDataTable("#skillsTable")) {
                $("#skillsTable").DataTable();
            } else {
                var table = $("#skillsTable").DataTable();
                table.draw(false);
            }
        },
        error: function(xhr, status, error) {
            Swal.close();
            Swal.fire("Error", "Could not fetch data: " + error, "error");
        }
    });
 
