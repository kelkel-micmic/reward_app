

	$.ajax({
	  url:"../api/employee-lists",
	  type: "GET",
	  dataType: "json",
	  beforeSend: (e) => {
	  Swal.fire({
	    html: 'Loading...',
	    didOpen: () => {
	      Swal.showLoading()
	    }
	  })
	  },
	  success: (data) => { 

	  	Swal.close();

	  	$("#emp-body").empty();

	  	$.each(data.employees, (i, e)=>{

	  		$("#emp-body").append(`
	  			<tr>
	  				<td>${e.id}</td>
	  				<td>${e.first_name}</td>
	  				<td>${e.middle_name}</td>
	  				<td>${e.last_name}</td>
	  				<td>
	  					<button class="btn btn-success btn-sm viewdetails" 
	  					data-id="${e.id}" 
	  					data-fname="${e.first_name}"
	  					data-middle="${e.middle_name}"
	  					data-lname="${e.last_name}"
	  					>Details</button>
	  				</td>
	  			</tr>
	  		`);

	  	});

	  	$("#emptable").DataTable();

	  },
	  error: (xhr, ajaxOptions, thrownError) => {

	      Swal.close(); 
	    
	      Swal.fire({
	        icon: 'error',
	        title: xhr.status,
	        text: thrownError,
	        confirmButtonColor: '#3085d6',
	        cancelButtonColor: '#d33',
	        confirmButtonText: 'Ok'
	      }).then((result) => {
	        if (result.isConfirmed) {
	         
	        }
	      });

	  }
	 });


	$(document).on("click", ".viewdetails", (e)=>{

		$("#view-modal").modal("show");

		$("#info-table").empty().append(`
      		<tbody>
      		  <tr>
      			<td><b>Fullname</b></td>
      			<td>${e.target.dataset.fname} ${e.target.dataset.middle_name} ${e.target.dataset.lname}</td>
      		  </tr>	
      		</tbody>
		`)

		console.log(e.target.dataset);

	});