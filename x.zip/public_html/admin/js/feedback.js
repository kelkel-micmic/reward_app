	$.ajax({
	  url:"../api/employee-lists",
	  type: "GET",
	  dataType: "json",
	  beforeSend: (e) => {
	  Swal.fire({
	    html: 'Loading...',
	    didOpen: () => {
	      Swal.showLoading()
	    }
	  })
	  },
	  success: (data) => { 

	  	Swal.close();

	  	$("#list-group").empty().append(`
			<div class="px-4 d-none d-md-block">
				<div class="d-flex align-items-center">
					<div class="flex-grow-1">
					
					</div>
				</div>
			</div>
	  	`);


	  	if ($("#feedback")[0].dataset.id == "") {
		  	$.each(data.employees, (i, e)=>{

		  		$("#list-group").append(`
					<a href="?feedback&empid=${e.id}" id="emp${e.id}" class="list-group-item list-group-item-action border-0">
						<div class="d-flex align-items-start">
							<img src="https://uxwing.com/wp-content/themes/uxwing/download/peoples-avatars/man-user-circle-icon.png" class="rounded-circle me-1" alt="Vanessa Tucker" width="40" height="40">
							<div class="flex-grow-1 ms-3">
								${e.fname} ${e.lname}
								<div class="small"><span class="fas fa-circle chat-online"></span> Employee</div>
							</div>
						</div>
					</a>
		  		`);

		  	});
	  	}else{

		  	$.each(data.employees, (i, e)=>{

		  		$("#list-group").append(`
					<a href="?feedback&empid=${e.id}" id="emp${e.id}" class="list-group-item list-group-item-action border-0">
						<div class="d-flex align-items-start">
							<img src="https://uxwing.com/wp-content/themes/uxwing/download/peoples-avatars/man-user-circle-icon.png" class="rounded-circle me-1" alt="Vanessa Tucker" width="40" height="40">
							<div class="flex-grow-1 ms-3">
								${e.fname} ${e.lname}
								<div class="small"><span class="fas fa-circle chat-online"></span> Employee</div>
							</div>
						</div>
					</a>
		  		`);

		  	});


			$.ajax({
			  url:"../api/get-feedback",
			  type: "POST",
			  dataType: "json",
			  data: {
			      empid: $("#feedback")[0].dataset.id
			  },
			  success: (datas) => { 
			  	
			  	$("#feed").empty();

			  	$.each(datas.feedbacks, (i, e)=>{

			  		$("#feed").append(`

						<a href="#" class="list-group-item list-group-item-action border-0">
							<div class="d-flex align-items-start">
								<img src="https://i.pinimg.com/736x/8b/16/7a/8b167af653c2399dd93b952a48740620.jpg" class="rounded-circle me-1" alt="Jennifer Chang" width="40" height="40">
								<div class="flex-grow-1 ms-3">
									${e.name}
									<div class="small" >
										<div id="rater${i}">
											
										</div>
									</div>
									${e.feedback}
								</div>
							</div>
						</a>
			  		`);


			        raterJs({
			                max:5, 
			                rating: Number(e.rating), 
			                starSize: 20,
			                element:document.querySelector("#rater"+i), 
			                disableText:"Custom disable text!", 
			                ratingText:"My custom rating text {rating}",
			                showToolTip:true,
			                rateCallback:function rateCallback(rating, done) {

			                    // starRating.setRating(rating); 
			                    // starRating.disable(); 
			                    // done(); 
			                }
			            })

			  	});

				$("#emp"+$("#feedback")[0].dataset.id).attr("class", "list-group-item list-group-item-action border-0 active");


			  }
			 });

		  	


	  	}	

	  },
	  error: (xhr, ajaxOptions, thrownError) => {

	      Swal.close(); 
	    
	      Swal.fire({
	        icon: 'error',
	        title: xhr.status,
	        text: thrownError,
	        confirmButtonColor: '#3085d6',
	        cancelButtonColor: '#d33',
	        confirmButtonText: 'Ok'
	      }).then((result) => {
	        if (result.isConfirmed) {
	         
	        }
	      });

	  }
	 });