$.ajax({
    url: "../api/termination-and-offbs",
    type: "GET",
    dataType: "json",
    beforeSend: function() {
        Swal.fire({
           title: 'Loading...',
            didOpen: () => {
                Swal.showLoading()
            },
            allowOutsideClick: false,
            allowEscapeKey: false
        });
    },
    success: function(response) {
        Swal.close();

        const tbody = $("#terminationTable tbody");
        tbody.empty();

        $.each(response.terminationData, function(i, termination) {
            const tr = $("<tr>").append(
                $("<td>").text(termination.employee_name),
                // $("<td>").text(new Date(termination.onboard_date).toLocaleDateString()),
                // $("<td>").text(new Date(termination.termination_date).toLocaleDateString()),
                $("<td>").text(termination.description),
                $("<td>").html(`<button class="btn btn-primary btn-sm reward-btn" data-employee-id="${termination.employee_id}">Reward</button><button class="btn btn-danger btn-sm cashreward-btn" data-employee-id="${termination.employee_id}">Cash Reward</button>`)
            );
            tbody.append(tr);
        });

        if (!$.fn.DataTable.isDataTable("#terminationTable")) {
            $("#terminationTable").DataTable();
        } else {
            var table = $("#terminationTable").DataTable();
            table.draw(false);
        }
    },
    error: function(xhr, status, error) {
        Swal.close();
        Swal.fire("Error", "Could not fetch data: " + error, "error");
    }
});



$(document).on('click', '.reward-btn', function() {
    var employeeId = $(this).data('employee-id');
    $('#employeeIdForReward').val(employeeId);
    $('#rewardModal').modal('show');
});

$(document).on('click', '.cashreward-btn', function() {
    var employeeId = $(this).data('employee-id');
    $('#employeeIdForReward').val(employeeId);
    $('#cashrewardModal').modal('show');
});




$('#submitReward').click(function() {
    var formData = {
        employeeId: $('#employeeIdForReward').val(),
        rewardType: $('#rewardType').val(),
        rewardDescription: $('#rewardDescription').val(),
        rewardDate: $('#rewardDate').val() 
    };

    $.ajax({
        url: "../api/add-reward", 
        type: "POST",
        data: formData,
        success: function(response) {
            $('#rewardModal').modal('hide');
            Swal.fire('Success', 'Reward added successfully!', 'success');
          	location.reload();
        },
        error: function(error) {
            
            Swal.fire('Error', 'There was an issue adding the reward.', 'error');
        }
    });
});

$(document).on('click','.request_cash_reward',function(){


    var formData = {
        employeeId: $('#employeeIdForReward').val(),
        cashrewardType: $('#cashrewardType').val(),
        cashrewardDescription: $('#cashrewardDescription').val(),
        RewardedDate: $('#RewardedDate').val() 
    };

    console.log(formData);


    $.ajax({
        url: "../api/add-cash-reward-request", 
        type: "POST",
        data: formData,
        success: function(response) {
            $('#cashrewardModal').modal('hide');
            Swal.fire('Success', 'Reward added successfully!', 'success');
          //	location.reload();
        },
        error: function(error) {
            
            Swal.fire('Error', 'There was an issue adding the reward.', 'error');
        }
    });


});


//$('#request_cash_reward').click(function() {

//  rewardType
//  RewardedDate
//  cashrewardDescription
//   console.log('here');
//     var formData = {
//         employeeId: $('#employeeIdForReward').val(),
//         rewardType: $('#rewardType').val(),
//         cashrewardDescription: $('#cashrewardDescription').val(),
//         RewardedDate: $('#RewardedDate').val() 
//     };

//     $.ajax({
//         url: "../api/add-cash-reward-request", 
//         type: "POST",
//         data: formData,
//         success: function(response) {
//             $('#cashrewardModal').modal('hide');
//             Swal.fire('Success', 'Reward added successfully!', 'success');
//           	location.reload();
//         },
//         error: function(error) {
            
//             Swal.fire('Error', 'There was an issue adding the reward.', 'error');
//         }
//     });
// });





