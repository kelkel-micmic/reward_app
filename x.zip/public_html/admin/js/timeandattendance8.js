$.ajax({
    url:"../api/attendance-data",
    type: "GET",
    dataType: "json",
    beforeSend: (e) => {
    Swal.fire({
      html: 'Loading...',
      didOpen: () => {
        Swal.showLoading()
      }
    })
    },
    success: (data) => { 

        Swal.close();

        $("#att-body").empty();

        $.each(data.employee, (i, e)=>{
            console.log(e);

            $("#att-body").append(`
                <tr>
                    <td>${e.first_name + e.middle_name}</td>
                    <td>${e.ave_absent}%</td>
                    <td>${e.ave_present}%</td>
                    <td>
                        <button class="btn btn-success btn-sm leave-modal" data-empid="${e.employee_id}">Request Leave</button>
                    </td>
                </tr>
            `);

        });

        $("#remote-tbl").DataTable();

    // 		$("#emp").text(data.employees);
    // 		$("#remote").text(data.remote);
    // 		$("#male").text(data.male);
    // 		$("#female").text(data.female);



    },
    error: (xhr, ajaxOptions, thrownError) => {

        Swal.close(); 
      
        Swal.fire({
          icon: 'error',
          title: xhr.status,
          text: thrownError,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ok'
        }).then((result) => {
          if (result.isConfirmed) {
           
          }
        });

    }
   });



  $(document).on("click", ".view", (e)=>{

        $.ajax({
            url:"../api/view-attendance",
            type: "POST",
            dataType: "json",
            data: {
                name: e.target.dataset.name
            },
            beforeSend: (e) => {
            Swal.fire({
              html: 'Loading...',
              didOpen: () => {
                Swal.showLoading()
              }
            })
            },
            success: (data) => { 

            Swal.close(); 

                $("#view-modal").modal("show");

                $("#att").empty();

                $.each(data.attendance, (i, e)=>{

                    $("#att").append(`
                  <tr>
                      <td><i class="fas fa-circle text-primary fa-fw"></i> ${e.date_inserted}</td>
                  </tr>
                    `);

                });

              var ctx = document.getElementById("chartjs-dashboard-line").getContext("2d");
              var gradient = ctx.createLinearGradient(0, 0, 0, 225);
              gradient.addColorStop(0, "rgba(215, 227, 244, 1)");
              gradient.addColorStop(1, "rgba(215, 227, 244, 0)");
              // Line chart
              new Chart(document.getElementById("chartjs-dashboard-line"), {
                  type: "line",
                  data: {
                      labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                      datasets: [{
                          label: "Attendance Average Per Month",
                          fill: true,
                          backgroundColor: gradient,
                          borderColor: window.theme.primary,
                          data: data.average
                      }]
                  },
                  options: {
                      maintainAspectRatio: false,
                      legend: {
                          display: false
                      },
                      tooltips: {
                          intersect: false
                      },
                      hover: {
                          intersect: true
                      },
                      plugins: {
                          filler: {
                              propagate: false
                          }
                      },
                      scales: {
                          xAxes: [{
                              reverse: true,
                              gridLines: {
                                  color: "rgba(0,0,0,0.0)"
                              }
                          }],
                          yAxes: [{
                              ticks: {
                                  stepSize: 1000
                              },
                              display: true,
                              borderDash: [3, 3],
                              gridLines: {
                                  color: "rgba(0,0,0,0.0)"
                              }
                          }]
                      }
                  }
              });

          }

        });

  });