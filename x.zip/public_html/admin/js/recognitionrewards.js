    $.ajax({
        url: "../api/recognition-and-rewards", 
        type: "GET",
        dataType: "json",
        beforeSend: function() {
            Swal.fire({
                title: 'Loading...',
                didOpen: () => {
                    Swal.showLoading()
                },
                allowOutsideClick: false,
                allowEscapeKey: false
            });
        },
        success: function(response) {
            Swal.close();

            const tbody = $("#rewardsTable tbody");
            tbody.empty();

            $.each(response.rewardsData, function(i, reward) {
                const tr = $("<tr>").append(
                    $("<td>").text(reward.first_name + " " +reward.last_name),
                    $("<td>").text(reward.reward_type),
                    $("<td>").text(new Date(reward.reward_date).toLocaleDateString()),
                    $("<td>").text(reward.reward_description)
                );
                tbody.append(tr);
            });

            if (!$.fn.DataTable.isDataTable("#rewardsTable")) {
                $("#rewardsTable").DataTable();
            } else {
                var table = $("#rewardsTable").DataTable();
                table.draw(false);
            }
        },
        error: function(xhr, status, error) {
            Swal.close();
            Swal.fire("Error", "Could not fetch data: " + error, "error");
        }
    });
