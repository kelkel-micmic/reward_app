    // Define a custom sorting function
    $.fn.dataTable.ext.type.order['competency-level-pre'] = function(d) {
        switch (d) {
            case 'Beginner': return 1;
            case 'Intermediate': return 2;
            case 'Advanced': return 3;
            case 'Expert': return 4;
            default: return 5; // Unknown or N/A competency levels
        }
    };

    $.ajax({
        url: "../api/succession-plannings", // Update this to your API endpoint
        type: "GET",
        dataType: "json",
        beforeSend: function() {
            Swal.fire({
                title: 'Loading...',
                didOpen: () => {
                    Swal.showLoading()
                },
                allowOutsideClick: false,
                allowEscapeKey: false
            });
        },
        success: function(response) {
            Swal.close();

            const tbody = $("#planningTable tbody");
            tbody.empty();

            $.each(response.planningData, function(i, item) {

                tbody.append(`<tr>
                <td>${item.employee_name}</td>
                <td>${item.skill_name || 'N/A'}</td>
                <td>${item.performance_scoring}</td>
                <td>${item.reward_type || 'N/A'}</td>
                <td>${item.competency_level}</td>
                </tr>`);
            });

            // Initialize or redraw DataTable with custom sorting
            if (!$.fn.DataTable.isDataTable("#planningTable")) {
                $("#planningTable").DataTable({
                    columnDefs: [
                        { targets: 4, type: 'competency-level' } // Assumes competency level is the 5th column (index 4)
                    ]
                });
            } else {
                var table = $("#planningTable").DataTable();
                table.draw();
            }
        },
        error: function(xhr, status, error) {
            Swal.close();
            Swal.fire("Error", "Could not fetch data: " + error, "error");
        }
    });
