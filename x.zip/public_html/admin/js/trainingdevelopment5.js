$(document).ready(function() {
    $('#addTrainingRewardModal').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget); 
        var employeeId = button.data('employee-id'); 
        
        if ($('#employeeForReward option').length <= 1) { 
            $.ajax({
                url: '../api/employee-lists',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    var employeeSelect = $('#employeeForReward');
                    employeeSelect.empty().append(new Option("Select Employee", ""));
                    $.each(response.employees, function(i, employee) {
                        employeeSelect.append(new Option(employee.first_name + " " + employee.last_name, employee.id));
                    });
                    if (employeeId) {
                        employeeSelect.val(employeeId);
                    }
                },
                error: function() {
                    console.error('Error fetching employee list.');
                }
            });
        } else if (employeeId) {
             $('#employeeForReward').val(employeeId);
        }
    });

    $.ajax({
        url: "../api/training-and-devs", 
        type: "GET",
        dataType: "json",
        beforeSend: function() {
            Swal.fire({
                title: 'Loading...',
                didOpen: () => {
                    Swal.showLoading()
                },
                allowOutsideClick: false,
                allowEscapeKey: false
            });
        },
        success: function(response) {
            Swal.close();
            const tbody = $("#trainingTable tbody");
            tbody.empty();

            $.each(response.trainingData, function(i, training) {
                console.log(training);
                const addRewardButton = `<button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addTrainingRewardModal" data-employee-id="${training.employee_id}">Add Reward</button>`;
                // const statusText = training.status === "0" ? "Ongoing" : "Finished";
                
                const tr = $("<tr>").append(
                    $("<td>").text(training.employee_name),
                    $("<td>").text(training.skill_name),
                    $("<td>").text(training.competency_level),
                    $("<td>").text(training.status),
                    $("<td>").html(addRewardButton) 
                );
                tbody.append(tr);
            });


            if (!$.fn.DataTable.isDataTable("#trainingTable")) {
                $("#trainingTable").DataTable();
            } else {
                var table = $("#trainingTable").DataTable();
                table.draw(false);
            }
        },
        error: function(xhr, status, error) {
            Swal.close();
            Swal.fire("Error", "Could not fetch data: " + error, "error");
        }
    });

    $('#addTrainingRewardForm').on('submit', function(e) {
        e.preventDefault(); 

        var formData = {
            employeeId: $('#employeeForReward').val(),
            rewardType: $('#trainingRewardType').val(),
            rewardDate: $('#trainingRewardDate').val(),
            rewardDescription: $('#trainingRewardDescription').val()
        };

        $.ajax({
            url: '../api/add-recognition-reward',
            type: 'POST',
            data: formData,
            success: function(response) {
                Swal.fire('Success', 'Reward added successfully!', 'success');
                $('#addTrainingRewardModal').modal('hide');
                location.reload();
            },
            error: function() {
                Swal.fire('Error', 'There was an issue adding the reward.', 'error');
            }
        });
    });
});




