$(document).ready(function() {
    $.ajax({
        url: "../api/performance-data", // Update this to match your actual API endpoint
        type: "GET",
        dataType: "json",
        beforeSend: (e) => {
            console.log(e);
            Swal.fire({
                title: 'Loading...',
                didOpen: () => {
                    Swal.showLoading()
                },
                allowOutsideClick: false,
                allowEscapeKey: false
            });
        },
        success: (data) => {
            console.log(data);
            Swal.close();

            $("#performance-data-body").empty();

            $.each(data.performanceData, (i, perfData) => {
                const employeeName = `${perfData.first_name} ${perfData.middle_name} ${perfData.last_name}`;
                $("#performance-data-body").append(`
                    <tr>
                        <td>${employeeName}</td>
                        <td>${perfData.ave_feedback_rating}</td>
                        <td>${perfData.ave_present}</td>
                        <td>${perfData.ave_absent}</td>
                        <td>${perfData.skill_name}</td>
                        <td>${perfData.skill_comp_level}</td>
                        <td>${new Date(perfData.date_inserted).toLocaleDateString()}</td>
                        <td>
                        </td>
                    </tr>
                `);
            });

            if (!$.fn.DataTable.isDataTable("#performanceDataTable")) {
                $("#performanceDataTable").DataTable();
            } else {
                var table = $("#performanceDataTable").DataTable();
                table.draw(false);
            }
        },
        error: (xhr, ajaxOptions, thrownError) => {
            Swal.close();
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: `Request failed: ${thrownError}`,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'OK'
            });
        }
    });
});
