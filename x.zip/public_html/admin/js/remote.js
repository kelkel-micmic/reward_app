

	$.ajax({
	  url:"../api/remote-lists",
	  type: "GET",
	  dataType: "json",
	  beforeSend: (e) => {
	  Swal.fire({
	    html: 'Loading...',
	    didOpen: () => {
	      Swal.showLoading()
	    }
	  })
	  },
	  success: (data) => { 

	  	Swal.close();

	  	$("#remote-body").empty();

	  	$.each(data.remote, (i, e)=>{

	  		$("#remote-body").append(`
	  			<tr>
	  				<td>${e.name}</td>
	  				<td>${e.gender}</td>
	  				<td>${e.department}</td>
	  				<td>${e.position}</td>
	  				<td>${e.start_date}</td>
	  				<td>${e.end_date}</td>
	  				<td>${e.reason}</td>
	  				<td>${e.shift}</td>
	  				<td>${e.status == 0 ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Inactive</span>'}</td>
	  			</tr>
	  		`);

	  	});

	  	$("#remote-tbl").DataTable();

	  },
	  error: (xhr, ajaxOptions, thrownError) => {

	      Swal.close(); 
	    
	      Swal.fire({
	        icon: 'error',
	        title: xhr.status,
	        text: thrownError,
	        confirmButtonColor: '#3085d6',
	        cancelButtonColor: '#d33',
	        confirmButtonText: 'Ok'
	      }).then((result) => {
	        if (result.isConfirmed) {
	         
	        }
	      });

	  }
	 });
