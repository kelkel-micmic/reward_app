<?php
session_start();

?>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="../img/icons/icon-48x48.png" />

	<link rel="canonical" href="https://demo-basic.adminkit.io/" />

	<title>Admin</title>

	<link href="../css/light.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs5/dt-1.11.3/datatables.min.css"/>
</head>

<body data-theme="default">
	<div class="wrapper">
		<nav id="sidebar" class="sidebar js-sidebar">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="index.html">

					<center>
						<img src="../img/logo.png" style="height: 70px;" alt="Charles Hall" /><br>
						<span class="align-middle" style="font-size: 25px; color: #DC2B7C;"><b><i style="color: #3b7ddd;">Human</i> Resource</b></span></center>
        		</a>

				<ul class="sidebar-nav">
					<li class="sidebar-header">
						Pages
					</li>

					<li class="sidebar-item <?php if (isset($_GET['recognitionrewards'])) { echo 'active'; } ?>">
						<a class="sidebar-link" href="?recognitionrewards">
			              <i class="align-middle" data-feather="trending-up"></i> <span class="align-middle">Recognition & Rewards</span>
			            </a>
					</li>

					<li class="sidebar-item <?php if (isset($_GET['successionplanning'])) { echo 'active'; } ?>">
						<a class="sidebar-link" href="?successionplanning">
			              <i class="align-middle" data-feather="trending-up"></i> <span class="align-middle">Succession Planning</span>
			            </a>
					</li>

					<li class="sidebar-item <?php if (isset($_GET['requestcashreward'])) { echo 'active'; } ?>">
						<a class="sidebar-link" href="?requestcashreward">
			              <i class="align-middle" data-feather="trending-up"></i> <span class="align-middle">Request Cash Reward</span>
			            </a>
					</li>

					<li class="sidebar-item <?php if (isset($_GET['terminationoffboarding'])) { echo 'active'; } ?>" >
						<a class="sidebar-link" href="?terminationoffboarding">
			              <i class="align-middle" data-feather="clock"></i> <span class="align-middle">Termination & Off Boarding</span>
			            </a>
					</li>

					<li class="sidebar-item <?php if (isset($_GET['employeeleaverequests'])) { echo 'active'; } ?>">
					    <a class="sidebar-link" href="?employeeleaverequests">
					        <i class="align-middle" data-feather="calendar"></i> <span class="align-middle">Leave Requests</span>
					    </a>
					</li>

					<li class="sidebar-item <?php if (isset($_GET['timeandattendance'])) { echo 'active'; } ?>">
						<a class="sidebar-link" href="?timeandattendance">
			              <i class="align-middle" data-feather="users"></i> <span class="align-middle">Time & Attendance</span>
			            </a>
					</li>

					<!-- <li class="sidebar-item <?php //if (isset($_GET['skillsandcompetency'])) { echo 'active'; } ?>">
						<a class="sidebar-link" href="?skillsandcompetency">
			              <i class="align-middle" data-feather="trending-up"></i> <span class="align-middle">Skills & Competency</span>
			            </a>
					</li> -->

					<li class="sidebar-item <?php if (isset($_GET['trainingdevelopment'])) { echo 'active'; } ?>">
						<a class="sidebar-link" href="?trainingdevelopment">
			              <i class="align-middle" data-feather="share-2"></i> <span class="align-middle">Training & Development</span>
			            </a>
					</li>

					<li class="sidebar-item <?php if (isset($_GET['performancemanagement'])) { echo 'active'; } ?>">
						<a class="sidebar-link" href="?performancemanagement">
			              <i class="align-middle" data-feather="zap"></i> <span class="align-middle">Performance Management</span>
			            </a>
					</li>

					<li class="sidebar-item <?php if (isset($_GET['employees'])) { echo 'active'; } ?>">
						<a class="sidebar-link" href="?employees">
			              <i class="align-middle" data-feather="users"></i> <span class="align-middle">Employees</span>
			            </a>
					</li>

				</ul>

			</div>
		</nav>

		<div class="main">
			<nav class="navbar navbar-expand navbar-light navbar-bg">
				<a class="sidebar-toggle js-sidebar-toggle">
          <i class="hamburger align-self-center"></i>
        </a>

				<div class="navbar-collapse collapse">
					<ul class="navbar-nav navbar-align">


						<li class="nav-item dropdown">
							<a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#" data-bs-toggle="dropdown">
				                <i class="align-middle" data-feather="settings"></i>
				            </a>

							<a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-bs-toggle="dropdown">
				                <img src="../img/logo.png" class="avatar img-fluid rounded me-1" alt="Charles Hall" /> <span class="text-dark">Admin HR</span>
				             </a>

							<div class="dropdown-menu dropdown-menu-end">
								<a class="dropdown-item" href="?profile"><i class="align-middle me-1" data-feather="user"></i> Profile</a>
								<div class="dropdown-divider"></div>
								<a class="dropdown-item" id="sign-out" style="cursor: pointer;">Log out</a>
							</div>
						</li>
					</ul>
				</div>
			</nav>

			<main class="content">
				<div class="container-fluid p-0">
					<?php 
					$pagesMap = [
						'employeeleaverequests' => 'pages/employee_leave_requests.php',
                        'recognitionrewards'     => 'pages/recognition_and_rewards.php',
                        'successionplanning'     => 'pages/succession_planning.php',
                        'terminationoffboarding' => 'pages/termination_and_offboarding.php',
                        'timeandattendance'      => 'pages/time_and_attendance.php',
                        'skillsandcompetency'    => 'pages/skills_and_competency.php',
                        'trainingdevelopment'    => 'pages/training_and_development.php',
                        'performancemanagement'  => 'pages/performance_management.php',
                        'employees'              => 'pages/employees.php',
						'requestcashreward'      => 'pages/requestcashreward.php'
                        
                    ];

                    $queryStringKey = strtolower(array_keys($_GET)[0] ?? '');

                    if (array_key_exists($queryStringKey, $pagesMap)) {
                        include $pagesMap[$queryStringKey];
                    }
					?>

				</div>
			</main>

			<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-start">
							<p class="mb-0">
								<a class="text-muted" href="https://adminkit.io/" target="_blank"><strong>Admin</strong></a> - <a class="text-muted" href="https://adminkit.io/" target="_blank"><strong>WorkFolio</strong></a>								&copy;
							</p>
						</div>
						<div class="col-6 text-end">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Support</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Help Center</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Privacy</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Terms</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>

	<script src="../js/light.js"></script>
	<script src="../js/datatables.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/v/bs5/dt-1.11.3/datatables.min.js"></script>
	<script src="https://cdn.lordicon.com/lordicon.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/rater-js@1.0.1/index.min.js"></script> 

	<?php
	 if (isset($_GET['recognitionrewards'])) {
        echo '<script src="js/recognitionrewards.js"></script>';
    } elseif (isset($_GET['successionplanning'])) {
        echo '<script src="js/successionplanning4.js"></script>';
    } elseif (isset($_GET['terminationoffboarding'])) {
        echo '<script src="js/terminationoffboarding_v2.js"></script>';
    } elseif (isset($_GET['timeandattendance'])) { 
        echo '<script src="js/timeandattendance13.js"></script>';
    } elseif (isset($_GET['skillsandcompetency'])) {
        echo '<script src="js/skillsandcompetency1.js"></script>';
    } elseif (isset($_GET['trainingdevelopment'])) {
        echo '<script src="js/trainingdevelopment5.js"></script>';
    } elseif (isset($_GET['performancemanagement'])) {
        echo '<script src="js/performancemanagement.js"></script>';
    } elseif (isset($_GET['employees'])) {
        echo '<script src="js/employees.js"></script>';
    } elseif (isset($_GET['employeeleaverequests'])) {

        echo '<script src="js/employeeleaverequests4.js"></script>';


    } elseif (isset($_GET['requestcashreward'])) {
        echo '<script src="js/requestcashreward.js"></script>';
    }  

	

	?>  

	<script type="text/javascript">
        $(document).on("click", "#sign-out", ()=>{


        $.ajax({
            url:"../api/user-logout",
            type: "POST",
            dataType: "json",
            data: {
                id: '<?= $_SESSION['system'][0]['id'] ?>'
            },
            beforeSend: (e) => {
            Swal.fire({
              html: 'Loading...',
              didOpen: () => {
                Swal.showLoading()
              }
            })
            },
            success: (data) => { 

            Swal.close(); 

 
                Swal.fire({
                  icon: 'success',
                  title: 'Logout succesfully.',
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Ok'
                }).then((result) => {
                  if (result.isConfirmed) {
                    window.location.href = "https://recognr-succps.workfoliohumanresource.com/index.php";
                  }
                })


          }

         }); 

        });

		</script>
</body>

</html>